import numpy as np
import statistics as stats

# ---------------------------
# 1. Create sample weather data
# ---------------------------

temperature = np.array([30, 32, 31, 33, 29, 28, 35, 34, 30, 31])
humidity = np.array([70, 65, 68, 72, 75, 80, 78, 77, 73, 69])
rainfall = np.array([5, 0, 12, 3, 0, 20, 25, 10, 2, 8])

# ---------------------------
# 2. Reshaping Example
# Convert temperature into 5 days × 2 readings
# ---------------------------

temp_reshaped = temperature.reshape(5, 2)

# ---------------------------
# 3. Broadcasting Example
# Add +2°C correction to temperature
# ---------------------------

corrected_temp = temperature + 2

# ---------------------------
# 4. NumPy Statistical Measures
# ---------------------------

numpy_mean = np.mean(temperature)
numpy_median = np.median(temperature)
numpy_variance = np.var(temperature)
numpy_std = np.std(temperature)

# ---------------------------
# 5. Built-in Python Results (for comparison)
# Convert NumPy array to Python list to avoid errors
# ---------------------------

temp_list = temperature.tolist()

python_mean = stats.mean(temp_list)
python_median = stats.median(temp_list)
python_variance = stats.pvariance(temp_list)   # population variance
python_std = stats.pstdev(temp_list)           # population std dev

# ---------------------------
# Print results
# ---------------------------

print("Reshaped Temperature (5x2):")
print(temp_reshaped)

print("\nCorrected Temperature (+2°C):")
print(corrected_temp)

print("\n--- NumPy Results ---")
print("Mean:", numpy_mean)
print("Median:", numpy_median)
print("Variance:", numpy_variance)
print("Standard Deviation:", numpy_std)

print("\n--- Python Built-in Results ---")
print("Mean:", python_mean)
print("Median:", python_median)
print("Variance:", python_variance)
print("Standard Deviation:", python_std)

