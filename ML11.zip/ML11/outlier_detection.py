import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import zscore

# -----------------------------
# 1. Load Dataset
# -----------------------------
df = pd.read_csv("numerical_data.csv")

print("\n=== Original Dataset Head ===")
print(df.head())

# -----------------------------
# 2. Outlier Detection using Z-score
# -----------------------------
df["Zscore"] = zscore(df["Value"])
z_outliers = df[abs(df["Zscore"]) > 3]     # threshold = 3

print("\n=== Outliers Detected by Z-score ===")
print(z_outliers)

# -----------------------------
# 3. Outlier Detection using IQR
# -----------------------------
Q1 = df["Value"].quantile(0.25)
Q3 = df["Value"].quantile(0.75)
IQR = Q3 - Q1

lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR

iqr_outliers = df[(df["Value"] < lower) | (df["Value"] > upper)]

print("\n=== Outliers Detected by IQR ===")
print(iqr_outliers)

# -----------------------------
# 4. Handling Outliers
# -----------------------------

### Method A: Remove Outliers
df_removed = df[(df["Value"] >= lower) & (df["Value"] <= upper)]

### Method B: Cap Outliers (Winsorization)
df_capped = df.copy()
df_capped["Value"] = np.where(df_capped["Value"] > upper, upper,
                        np.where(df_capped["Value"] < lower, lower, df_capped["Value"]))

# -----------------------------
# 5. Compare Distributions
# -----------------------------
plt.figure(figsize=(12,5))

plt.subplot(1,3,1)
plt.boxplot(df["Value"])
plt.title("Original Data")

plt.subplot(1,3,2)
plt.boxplot(df_removed["Value"])
plt.title("After Removing Outliers")

plt.subplot(1,3,3)
plt.boxplot(df_capped["Value"])
plt.title("After Capping Outliers")

plt.tight_layout()
plt.show()

# -----------------------------
# 6. Save cleaned versions
# -----------------------------
df_removed.to_csv("clean_removed.csv", index=False)
df_capped.to_csv("clean_capped.csv", index=False)

print("\n✔ Cleaned files saved as:")
print("   clean_removed.csv")
print("   clean_capped.csv")
