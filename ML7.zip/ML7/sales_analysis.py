import pandas as pd

# ------------------------------------------
# 1. LOAD DATASET
# ------------------------------------------
data = pd.read_csv("sales_data.csv")
print("\n===== FIRST 5 ROWS =====")
print(data.head())

# ------------------------------------------
# 2. DESCRIPTIVE REPORT
# ------------------------------------------
print("\n===== DATA INFO =====")
print(data.info())

print("\n===== DESCRIBE() OUTPUT =====")
print(data.describe())

# ------------------------------------------
# 3. FILTER RECORDS (Sales > 500)
# ------------------------------------------
filtered = data[data["Sales"] > 500]
print("\n===== FILTERED DATA (Sales > 500) =====")
print(filtered)

# ------------------------------------------
# 4. GROUPBY AGGREGATION (BY REGION)
# ------------------------------------------
region_summary = filtered.groupby("Region")["Sales"].sum()
print("\n===== TOTAL SALES BY REGION =====")
print(region_summary)

# ------------------------------------------
# 5. GROUPBY AGGREGATION (BY PRODUCT)
# ------------------------------------------
product_summary = filtered.groupby("Product")["Sales"].sum()
print("\n===== TOTAL SALES BY PRODUCT =====")
print(product_summary)

# ------------------------------------------
# 6. SUMMARY REPORT
# ------------------------------------------
print("\n===== SUMMARY REPORT =====")
print("Total records:", len(data))
print("Records with Sales > 500:", len(filtered))

print("\nSales Summary by Region:\n", region_summary)
print("\nSales Summary by Product:\n", product_summary)
