import os
import pandas as pd

# ------------------------------
# Step 1: Define file names
# ------------------------------
csv_file = "data1.csv"
excel_file = "data2.xlsx"
json_file = "data3.json"

# ------------------------------
# Step 2: Create sample files if they don't exist
# ------------------------------
if not os.path.exists(csv_file):
    df_csv = pd.DataFrame({
        "CustomerID": [1, 2, 3],
        "Age": [25, 30, 22],
        "Purchase": [100, 150, 200]
    })
    df_csv.to_csv(csv_file, index=False)

if not os.path.exists(excel_file):
    df_excel = pd.DataFrame({
        "CustomerID": [4, 5, 6],
        "Age": [28, 35, 40],
        "Purchase": [250, 300, 350]
    })
    df_excel.to_excel(excel_file, index=False)

if not os.path.exists(json_file):
    df_json = pd.DataFrame({
        "CustomerID": [7, 8, 9],
        "Age": [45, 50, 38],
        "Purchase": [400, 450, 500]
    })
    df_json.to_json(json_file, orient="records")

# ------------------------------
# Step 3: Read the files
# ------------------------------
df_csv = pd.read_csv(csv_file)
df_excel = pd.read_excel(excel_file)
df_json = pd.read_json(json_file)

# ------------------------------
# Step 4: Combine datasets
# ------------------------------
df_combined = pd.concat([df_csv, df_excel, df_json], ignore_index=True)

# ------------------------------
# Step 5: Clean combined data
# ------------------------------
# Fill missing values if any
df_combined.fillna(df_combined.median(numeric_only=True), inplace=True)

# Ensure proper indexing
df_combined.reset_index(drop=True, inplace=True)

# ------------------------------
# Step 6: Descriptive statistics
# ------------------------------
mean_purchase = df_combined['Purchase'].mean()

# ------------------------------
# Step 7: Display results
# ------------------------------
print("=== Combined Dataset ===")
print(df_combined)
print(f"\nMean Purchase across all combined data: {mean_purchase:.2f}")

