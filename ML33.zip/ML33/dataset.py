# student_dataset_generation.py

import numpy as np
import pandas as pd

# Set random seed for reproducibility
np.random.seed(42)

# Number of samples
n_samples = 200

# Generate features
study_hours = np.random.randint(1, 11, n_samples)          # 1 to 10 hours
attendance = np.random.randint(50, 101, n_samples)         # 50% to 100%
previous_grade = np.random.choice(['A', 'B', 'C'], n_samples)
extracurricular = np.random.choice(['Yes', 'No'], n_samples)

# Define pass/fail based on simple logic
pass_fail = np.where((study_hours >= 5) & (attendance >= 70), 'Pass', 'Fail')

# Create DataFrame
df = pd.DataFrame({
    'study_hours': study_hours,
    'attendance': attendance,
    'previous_grade': previous_grade,
    'extracurricular': extracurricular,
    'pass_fail': pass_fail
})

# Save to CSV
df.to_csv('student_performance_dataset.csv', index=False)

# Preview
print("=== Generated Dataset Preview ===")
print(df.head())
print("\nClass distribution:")
print(df['pass_fail'].value_counts())

