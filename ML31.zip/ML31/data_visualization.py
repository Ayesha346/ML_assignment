# data_visualization.py

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris

# Load dataset
iris = load_iris()
df = pd.DataFrame(data=iris.data, columns=iris.feature_names)
df['species'] = pd.Categorical.from_codes(iris.target, iris.target_names)

# Display first few rows
print("=== Dataset Preview ===")
print(df.head())

# 1. Pairplot (scatter plots and histograms)
sns.pairplot(df, hue='species', corner=True)
plt.suptitle("Pairplot of Iris Features by Species", y=1.02)
plt.show()

# 2. Heatmap of feature correlations
correlation_matrix = df.iloc[:, :-1].corr()
print("\n=== Feature Correlation Matrix ===")
print(correlation_matrix)

plt.figure(figsize=(8, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title("Heatmap of Feature Correlations")
plt.show()

# 3. Scatter plot: Petal Length vs Petal Width colored by species
plt.figure(figsize=(6, 4))
sns.scatterplot(data=df, x='petal length (cm)', y='petal width (cm)', hue='species', style='species', s=80)
plt.title("Petal Length vs Petal Width")
plt.show()

# 4. Boxplots for feature distributions across species
plt.figure(figsize=(8, 5))
sns.boxplot(data=df, x='species', y='sepal length (cm)', palette='Set2')
plt.title("Sepal Length Distribution by Species")
plt.show()
