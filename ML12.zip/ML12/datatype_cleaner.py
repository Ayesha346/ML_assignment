import pandas as pd
import numpy as np

def clean_and_validate(df):
    print("\n=== Original Data Types ===")
    print(df.dtypes)

    # Identify numeric columns automatically (exclude Name)
    numeric_cols = ["Age", "Salary", "Experience"]

    # Convert numeric columns only
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    print("\n=== After Type Conversion ===")
    print(df.dtypes)

    # Business rules
    invalid_records = []

    for idx, row in df.iterrows():
        issues = []

        # Missing numeric values
        if row[numeric_cols].isnull().any():
            issues.append("Missing/Non-numeric values")

        # Age must be positive
        if not pd.isna(row["Age"]) and row["Age"] <= 0:
            issues.append("Invalid Age")

        # Experience must be non-negative
        if not pd.isna(row["Experience"]) and row["Experience"] < 0:
            issues.append("Invalid Experience")

        if issues:
            invalid_records.append((idx, row.to_dict(), issues))

    # Print invalid records
    print("\n=== Invalid Records Found ===")
    for idx, rec, issues in invalid_records:
        print(f"Row {idx} → {rec} → Issues: {issues}")

    print("\n=== Cleaned DataFrame ===")
    print(df)

    return df


# ---------------------------
# SAMPLE DATA
# ---------------------------
data = {
    "Name": ["John", "Anna", "Ravi", "Kiran", "Meera"],
    "Age": ["25", "-5", "30", "40", "abc"],
    "Salary": ["45000", "50000", "NaN", "60000", "55000"],
    "Experience": ["2", "1", "3", "-2", "4"]
}

df = pd.DataFrame(data)

cleaned_df = clean_and_validate(df)

