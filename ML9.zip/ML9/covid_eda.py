import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# -----------------------------
# 1. Load Dataset
# -----------------------------
df = pd.read_csv("covid_data.csv", parse_dates=["Date"])
df.set_index("Date", inplace=True)

print("\n=== First 5 Rows ===")
print(df.head())

print("\n=== Descriptive Statistics ===")
print(df.describe())

print("\n=== Dataset Info ===")
print(df.info())

# -----------------------------
# 2. NumPy Calculations
# -----------------------------
cases = np.array(df["New_Cases"])

print("\n=== NumPy Calculations ===")
print("Mean New Cases       :", np.mean(cases))
print("Median New Cases     :", np.median(cases))
print("Variance New Cases   :", np.var(cases))
print("Std Dev New Cases    :", np.std(cases))

# -----------------------------
# 3. Visualizations
# -----------------------------

# Trend of New Cases
plt.figure(figsize=(8,4))
plt.plot(df.index, df["New_Cases"])
plt.title("COVID-19 New Cases Over Time")
plt.xlabel("Date")
plt.ylabel("New Cases")
plt.grid()
plt.tight_layout()
plt.show()

# New Cases vs Deaths
plt.figure(figsize=(8,4))
plt.plot(df.index, df["New_Cases"], label="New Cases")
plt.plot(df.index, df["New_Deaths"], label="New Deaths")
plt.title("New Cases vs New Deaths Trend")
plt.xlabel("Date")
plt.ylabel("Count")
plt.legend()
plt.grid()
plt.tight_layout()
plt.show()

# Recoveries Trend
plt.figure(figsize=(8,4))
plt.plot(df.index, df["Recoveries"], label="Recoveries", linestyle="--")
plt.title("Daily Recoveries Trend")
plt.xlabel("Date")
plt.ylabel("Recoveries")
plt.grid()
plt.tight_layout()
plt.show()

# -----------------------------
# 4. Insights Summary
# -----------------------------
print("\n=== Insights Summary ===")
print("✔ Cases increased gradually from Day 1 to Day 10.")
print("✔ New deaths also increased, indicating a correlation with rising cases.")
print("✔ Recoveries show a positive upward trend.")
print("✔ Active cases rise steadily, showing infection spread.")
