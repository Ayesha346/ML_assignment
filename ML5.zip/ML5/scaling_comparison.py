import pandas as pd
import numpy as np
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import warnings
warnings.filterwarnings("ignore")

# ----------------------------------------------------------
# 1. LOAD REAL-WORLD DATASET (Titanic from seaborn)
# ----------------------------------------------------------
df = sns.load_dataset("titanic")

print("Original Shape:", df.shape)

# ----------------------------------------------------------
# 2. DATA CLEANING
# ----------------------------------------------------------

# Remove duplicates
df = df.drop_duplicates()
print("After removing duplicates:", df.shape)

# Handle missing values
df['age'] = df['age'].fillna(df['age'].median())
df['fare'] = df['fare'].fillna(df['fare'].median())
df['embarked'] = df['embarked'].fillna(df['embarked'].mode()[0])

# Convert categorical → numeric
df['sex'] = df['sex'].map({"male": 0, "female": 1})
df['embarked'] = df['embarked'].map({"S": 0, "C": 1, "Q": 2})

# Keep only needed features
df = df[['survived', 'age', 'fare', 'sex', 'pclass']]

print("\nCleaned data preview:")
print(df.head())

# ----------------------------------------------------------
# 3. PREPARE FEATURES + SPLIT
# ----------------------------------------------------------
X = df[['age', 'fare', 'sex', 'pclass']]
y = df['survived']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# ----------------------------------------------------------
# 4. DIFFERENT SCALING TECHNIQUES
# ----------------------------------------------------------

# a) Min-Max Scaling
minmax = MinMaxScaler()
X_train_minmax = minmax.fit_transform(X_train)
X_test_minmax = minmax.transform(X_test)

# b) Z-score Normalization
zscore = StandardScaler()
X_train_zscore = zscore.fit_transform(X_train)
X_test_zscore = zscore.transform(X_test)

# c) Log Transformation (apply to positive numeric values)
X_train_log = np.log(X_train + 1)
X_test_log = np.log(X_test + 1)

# ----------------------------------------------------------
# 5. MODEL TRAINING & PERFORMANCE COMPARISON
# ----------------------------------------------------------

def evaluate_model(X_train, X_test, y_train, y_test):
    model = LogisticRegression()
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    return accuracy_score(y_test, preds)

acc_minmax = evaluate_model(X_train_minmax, X_test_minmax, y_train, y_test)
acc_zscore = evaluate_model(X_train_zscore, X_test_zscore, y_train, y_test)
acc_log = evaluate_model(X_train_log, X_test_log, y_train, y_test)

print("\n--- MODEL PERFORMANCE COMPARISON ---")
print("Min-Max Scaling Accuracy:", acc_minmax)
print("Z-score Normalization Accuracy:", acc_zscore)
print("Log Transformation Accuracy:", acc_log)
