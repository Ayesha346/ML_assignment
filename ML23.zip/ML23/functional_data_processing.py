import pandas as pd
import numpy as np

# -----------------------------
# 1. Sample messy dataset
# -----------------------------
data = {
    'Name': ['John', 'Anna', 'Ravi', 'Kiran', 'Meera'],
    'Age': ['25', '-5', '30', '40', None],
    'Salary': ['45000', '50000', None, '60000', '55000'],
    'Experience': [2, 1, 3, -2, 4]
}

df = pd.DataFrame(data)
print("=== Original DataFrame ===")
print(df)

# -----------------------------
# 2. Custom function: convert columns to numeric and handle errors
# -----------------------------
def convert_numeric(col):
    """Converts a column to numeric, coercing errors to NaN"""
    return pd.to_numeric(col, errors='coerce')

# -----------------------------
# 3. Lambda function: flag invalid ages
# -----------------------------
flag_invalid_age = lambda age: 'Invalid' if (age is None or age < 0) else 'Valid'

# -----------------------------
# 4. Apply functions to DataFrame
# -----------------------------
df['Age'] = convert_numeric(df['Age'])
df['Salary'] = convert_numeric(df['Salary'])
df['Age_Status'] = df['Age'].apply(flag_invalid_age)

# Remove negative experience values
df['Experience'] = df['Experience'].apply(lambda x: np.nan if x < 0 else x)

# Fill missing values with median
df['Age'].fillna(df['Age'].median(), inplace=True)
df['Salary'].fillna(df['Salary'].median(), inplace=True)
df['Experience'].fillna(df['Experience'].median(), inplace=True)

# -----------------------------
# 5. Display cleaned DataFrame
# -----------------------------
print("\n=== Cleaned DataFrame ===")
print(df)

# -----------------------------
# 6. Additional functional programming: create Total Compensation
# -----------------------------
df['Total_Comp'] = df.apply(lambda row: row['Salary'] + row['Experience']*1000, axis=1)

print("\n=== DataFrame with Total Compensation ===")
print(df)
