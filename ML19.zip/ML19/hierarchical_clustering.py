import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.datasets import make_blobs

# -----------------------------
# 1. Use the same dataset (synthetic customer data)
# -----------------------------
X, _ = make_blobs(n_samples=300, centers=5, cluster_std=1.5, random_state=42)
df = pd.DataFrame(X, columns=['AnnualIncome', 'SpendingScore'])

print("\n=== Dataset Preview ===")
print(df.head())

# -----------------------------
# 2. Standardization
# -----------------------------
scaler = StandardScaler()
scaled_data = scaler.fit_transform(df)

# -----------------------------
# 3. Generate Dendrogram
# -----------------------------
plt.figure(figsize=(10,5))
linked = linkage(scaled_data, method='ward')
dendrogram(linked)
plt.title("Hierarchical Clustering Dendrogram")
plt.xlabel("Customers")
plt.ylabel("Distance")
plt.show()

# -----------------------------
# 4. Apply Hierarchical Clustering
# -----------------------------
optimal_k = 5  # From dendrogram "elbow"/height jump
hier_clust = AgglomerativeClustering(n_clusters=optimal_k, linkage='ward')
df['Hier_Cluster'] = hier_clust.fit_predict(scaled_data)

# -----------------------------
# 5. Visualize Clusters
# -----------------------------
plt.figure(figsize=(6,4))
plt.scatter(df['AnnualIncome'], df['SpendingScore'], c=df['Hier_Cluster'], cmap='Set1')
plt.xlabel("Annual Income")
plt.ylabel("Spending Score")
plt.title(f"Hierarchical Clustering (K={optimal_k})")
plt.show()

# -----------------------------
# 6. Cluster Summary
# -----------------------------
cluster_summary = df.groupby('Hier_Cluster').mean()
print("\n=== Hierarchical Cluster Summary ===")
print(cluster_summary)
