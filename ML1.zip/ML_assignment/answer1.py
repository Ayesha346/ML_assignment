import csv
import time

# Load data from CSV into different structures
list_data = []
tuple_data = []
set_data = set()
dict_data = {}

with open("employees.csv", "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        row["salary"] = int(row["salary"])
        list_data.append(row)
        tuple_data.append((row["id"], row["name"], row["department"], row["salary"]))
        set_data.add((row["id"], row["name"], row["department"], row["salary"]))
        dict_data[row["id"]] = row

tuple_data = tuple(tuple_data)

# Helper for timing
def measure(func, *args):
    start = time.perf_counter()
    output = func(*args)
    end = time.perf_counter()
    return output, end - start

# Retrieval
def get_list(name):
    return next((x for x in list_data if x["name"] == name), None)

def get_tuple(name):
    return next((x for x in tuple_data if x[1] == name), None)

def get_set(name):
    return next((x for x in set_data if x[1] == name), None)

def get_dict(name):
    for x in dict_data.values():
        if x["name"] == name:
            return x
    return None

# Filtering
def filter_list(d):
    return [x for x in list_data if x["department"] == d]

def filter_tuple(d):
    return [x for x in tuple_data if x[2] == d]

def filter_set(d):
    return [x for x in set_data if x[2] == d]

def filter_dict(d):
    return [x for x in dict_data.values() if x["department"] == d]

# Aggregation
def agg_list():
    return sum(x["salary"] for x in list_data)

def agg_tuple():
    return sum(x[3] for x in tuple_data)

def agg_set():
    return sum(x[3] for x in set_data)

def agg_dict():
    return sum(x["salary"] for x in dict_data.values())

# Performance tests
print("\n--- Retrieval Performance ---")
for name, func in [
    ("List", get_list),
    ("Tuple", get_tuple),
    ("Set", get_set),
    ("Dict", get_dict)
]:
    res, t = measure(func, "Ayesha")
    print(f"{name:10} | {t:.8f}s | {res}")

print("\n--- Filtering Performance (IT Dept) ---")
for name, func in [
    ("List", filter_list),
    ("Tuple", filter_tuple),
    ("Set", filter_set),
    ("Dict", filter_dict)
]:
    res, t = measure(func, "IT")
    print(f"{name:10} | {t:.8f}s | {res}")

print("\n--- Aggregation Performance (Total Salary) ---")
for name, func in [
    ("List", agg_list),
    ("Tuple", agg_tuple),
    ("Set", agg_set),
    ("Dict", agg_dict)
]:
    res, t = measure(func)
    print(f"{name:10} | {t:.8f}s | {res}")
