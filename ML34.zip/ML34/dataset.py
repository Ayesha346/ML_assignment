import pandas as pd
import numpy as np

# Generate synthetic Titanic-like dataset
data = {
    'Pclass': np.random.choice([1,2,3], 100),
    'Sex': np.random.choice(['male','female'], 100),
    'Age': np.random.randint(1, 80, 100),
    'SibSp': np.random.randint(0, 5, 100),
    'Parch': np.random.randint(0, 5, 100),
    'Fare': np.random.uniform(10, 500, 100),
    'Embarked': np.random.choice(['C','Q','S'], 100),
    'Survived': np.random.choice([0,1], 100)
}

df = pd.DataFrame(data)
print("=== Synthetic Dataset Preview ===")
print(df.head())
