# full_pipeline_analysis.py

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.cluster import KMeans

# -------------------------------
# 1. Generate synthetic dataset
# -------------------------------
np.random.seed(42)
n = 100  # number of samples

df = pd.DataFrame({
    'Pclass': np.random.choice([1,2,3], n),
    'Sex': np.random.choice(['male','female'], n),
    'Age': np.random.randint(1, 80, n),
    'SibSp': np.random.randint(0, 5, n),
    'Parch': np.random.randint(0, 5, n),
    'Fare': np.round(np.random.uniform(10, 500, n),2),
    'Embarked': np.random.choice(['C','Q','S'], n),
    'Survived': np.random.choice([0,1], n)
})

print("=== Synthetic Dataset Preview ===")
print(df.head())

# -------------------------------
# 2. Data Preprocessing
# -------------------------------
# Encode categorical variables
le_sex = LabelEncoder()
df['Sex'] = le_sex.fit_transform(df['Sex'])  # male=1, female=0

le_emb = LabelEncoder()
df['Embarked'] = le_emb.fit_transform(df['Embarked'])  # C=0, Q=1, S=2

# Feature scaling
scaler = StandardScaler()
num_features = ['Age', 'Fare', 'SibSp', 'Parch']
df[num_features] = scaler.fit_transform(df[num_features])

# Split features and target
X = df.drop('Survived', axis=1)
y = df['Survived']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# -------------------------------
# 3. Supervised Models
# -------------------------------
models = {
    'Logistic Regression': LogisticRegression(),
    'Decision Tree': DecisionTreeClassifier(),
    'Random Forest': RandomForestClassifier()
}

for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)
    
    print(f"\n=== {name} ===")
    print(f"Accuracy : {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall   : {rec:.4f}")
    print(f"F1-score : {f1:.4f}")
    print("Confusion Matrix:")
    print(cm)

# -------------------------------
# 4. Unsupervised Model: KMeans
# -------------------------------
kmeans = KMeans(n_clusters=2, random_state=42)
cluster_features = ['Pclass', 'Sex', 'Age', 'Fare']
df['Cluster'] = kmeans.fit_predict(df[cluster_features])

print("\n=== KMeans Clustering Result ===")
print(df[['Pclass','Sex','Age','Fare','Cluster']].head())

# -------------------------------
# 5. Visualization & EDA
# -------------------------------
# Correlation Heatmap
plt.figure(figsize=(8,6))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.show()

# Pairplot colored by Survived
sns.pairplot(df, hue='Survived', vars=['Age','Fare','SibSp','Parch'])
plt.show()

# Count plot of clusters
sns.countplot(x='Cluster', hue='Survived', data=df)
plt.title("Cluster vs Survived Count")
plt.show()
