# KNN Classification with Optimal K using Cross-Validation
# Dataset: Iris (Classification Dataset)

import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# ------------------------------
# Load Dataset
# ------------------------------
iris = load_iris()
X = iris.data
y = iris.target

# ------------------------------
# Feature Scaling
# ------------------------------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ------------------------------
# K Values to Test
# ------------------------------
k_values = [3, 5, 7, 9]
cv_scores = []

# ------------------------------
# Cross-Validation for Each K
# ------------------------------
for k in k_values:
    knn = KNeighborsClassifier(n_neighbors=k)
    scores = cross_val_score(knn, X_scaled, y, cv=5)  # 5-fold CV
    cv_scores.append(scores.mean())
    print(f"K = {k} → Mean CV Accuracy = {scores.mean():.4f}")

# ------------------------------
# Determine Optimal K
# ------------------------------
optimal_k = k_values[np.argmax(cv_scores)]
print("\nOptimal K based on Cross-Validation:", optimal_k)

# ------------------------------
# Plot Accuracy vs K
# ------------------------------
plt.plot(k_values, cv_scores, marker='o')
plt.xlabel("K Value")
plt.ylabel("Cross-Validation Accuracy")
plt.title("KNN Performance for Different K Values")
plt.grid()
plt.show()
