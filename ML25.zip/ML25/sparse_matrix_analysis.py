import numpy as np

# Step 1: Create a large sparse matrix (mostly zeros)
rows, cols = 1000, 1000  # 1 million elements
density = 0.01  # 1% non-zero
num_nonzero = int(rows * cols * density)

# Initialize matrix with zeros
sparse_matrix = np.zeros((rows, cols))

# Randomly assign some non-zero values
indices = np.random.choice(rows * cols, num_nonzero, replace=False)
sparse_matrix.flat[indices] = np.random.randint(1, 100, size=num_nonzero)

print(f"Original matrix shape: {sparse_matrix.shape}")
print(f"Number of non-zero elements: {np.count_nonzero(sparse_matrix)}")

# Step 2: Efficient storage using coordinate (COO) format
def convert_to_coo(matrix):
    """Convert a 2D sparse matrix to COO format (row, col, value)."""
    row_idx, col_idx = np.nonzero(matrix)
    values = matrix[row_idx, col_idx]
    return row_idx, col_idx, values

row_idx, col_idx, values = convert_to_coo(sparse_matrix)
print(f"COO representation has {len(values)} entries.")

# Step 3: Custom function to compute non-zero mean
def non_zero_mean(coo_values):
    """Compute mean of non-zero elements from COO values."""
    if len(coo_values) == 0:
        return 0
    return np.mean(coo_values)

nz_mean = non_zero_mean(values)
print(f"Mean of non-zero elements: {nz_mean:.2f}")

# Step 4: Additional stats on sparse matrix
def sparse_stats(coo_values):
    return {
        "non_zero_count": len(coo_values),
        "non_zero_mean": np.mean(coo_values) if len(coo_values) > 0 else 0,
        "max_value": np.max(coo_values) if len(coo_values) > 0 else 0,
        "min_value": np.min(coo_values) if len(coo_values) > 0 else 0
    }

stats = sparse_stats(values)
print("Sparse matrix statistics:", stats)
