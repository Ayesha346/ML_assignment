# large_data_optimization.py
import pandas as pd
import numpy as np
import time

# =======================
# Generate Large Dataset
# =======================
num_rows = 2_000_000  # 2 million rows
np.random.seed(42)

data = {
    "CustomerID": np.arange(1, num_rows + 1),
    "Age": np.random.randint(18, 80, size=num_rows),
    "Salary": np.random.randint(20000, 150000, size=num_rows),
    "Purchase": np.random.randint(100, 10000, size=num_rows),
    "Category": np.random.choice(['A', 'B', 'C', 'D'], size=num_rows)
}

df = pd.DataFrame(data)

# Save to CSV for simulation
csv_file = "large_dataset.csv"
df.to_csv(csv_file, index=False)
print(f"Generated dataset with {num_rows} rows and saved to '{csv_file}'\n")

# =======================
# Load and Measure Memory
# =======================
start_time = time.time()
df_full = pd.read_csv(csv_file)
end_time = time.time()

print(f"Memory usage before optimization: {df_full.memory_usage(deep=True).sum() / 1024**2:.2f} MB")
print(f"Time to load full CSV: {end_time - start_time:.2f} sec\n")

# =======================
# Memory Optimization
# =======================
# Convert integers to smaller types
df_optimized = df_full.copy()
df_optimized['Age'] = df_optimized['Age'].astype(np.uint8)
df_optimized['Salary'] = df_optimized['Salary'].astype(np.uint32)
df_optimized['Purchase'] = df_optimized['Purchase'].astype(np.uint32)

# Convert categorical column to 'category'
df_optimized['Category'] = df_optimized['Category'].astype('category')

# Set proper index
df_optimized.set_index('CustomerID', inplace=True)

print(f"Memory usage after optimization: {df_optimized.memory_usage(deep=True).sum() / 1024**2:.2f} MB\n")

# =======================
# Basic Statistics
# =======================
print("Basic Descriptive Statistics (Optimized Data):\n")
print(df_optimized.describe(include='all'))

# =======================
# Non-zero mean example
# =======================
non_zero_purchase_mean = df_optimized['Purchase'][df_optimized['Purchase'] > 0].mean()
print(f"\nMean of non-zero Purchase values: {non_zero_purchase_mean:.2f}")

# =======================
# Performance Improvement Summary
# =======================
original_mem = df_full.memory_usage(deep=True).sum() / 1024**2
optimized_mem = df_optimized.memory_usage(deep=True).sum() / 1024**2
print(f"\nPerformance Improvement: Memory reduced by {original_mem - optimized_mem:.2f} MB")

