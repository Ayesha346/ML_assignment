import pandas as pd
import numpy as np

# Number of rows
n_rows = 1_000_000

# Random data generation
np.random.seed(42)
data = {
    'CustomerID': np.arange(1, n_rows + 1),
    'Age': np.random.randint(18, 80, size=n_rows),
    'Salary': np.random.randint(20000, 150000, size=n_rows),
    'PurchaseAmount': np.random.randint(100, 5000, size=n_rows),
    'Category': np.random.choice(['A', 'B', 'C', 'D'], size=n_rows)
}

# Create DataFrame
df = pd.DataFrame(data)

# Save to CSV
df.to_csv('large_dataset.csv', index=False)

print("Large dataset created: 'large_dataset.csv'")
