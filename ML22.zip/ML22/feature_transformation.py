import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.preprocessing import KBinsDiscretizer
import seaborn as sns

# -----------------------------
# 1. Load dataset (Seaborn diamonds dataset)
# -----------------------------
df = sns.load_dataset("diamonds")

# Use only 'carat' (continuous) and 'price' (target)
df = df[['carat', 'price']].dropna()

print("=== Original Data ===")
print(df.head())

# -----------------------------
# 2. Apply Transformations
# -----------------------------
df['Log_carat'] = np.log1p(df['carat'])                # log(x+1) to avoid log(0)
df['Sqrt_carat'] = np.sqrt(df['carat'])               # square root
df['BoxCox_carat'], _ = stats.boxcox(df['carat'] + 1)  # Box-Cox requires positive values

# -----------------------------
# 3. Apply Discretization (Binning)
# -----------------------------
kbd = KBinsDiscretizer(n_bins=5, encode='ordinal', strategy='quantile')
df['Binned_carat'] = kbd.fit_transform(df[['carat']])

# -----------------------------
# 4. Analyze Distributions
# -----------------------------
features = ['carat', 'Log_carat', 'Sqrt_carat', 'BoxCox_carat', 'Binned_carat']

for feat in features:
    print(f"\n=== {feat} ===")
    print(df[feat].describe())
    corr = df[feat].corr(df['price'])
    print(f"Correlation with price: {corr:.4f}")
    
    # Plot histogram
    plt.figure(figsize=(6,4))
    plt.hist(df[feat], bins=20, color='skyblue', edgecolor='black')
    plt.title(f'Distribution of {feat}')
    plt.xlabel(feat)
    plt.ylabel('Frequency')
    plt.show()

