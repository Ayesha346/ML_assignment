import pandas as pd

# 1. Load dataset (replace with your own file path)
df = pd.read_csv("messy_dataset.csv")

print("Original Shape:", df.shape)

# 2. Remove duplicate rows
df = df.drop_duplicates()
print("After Removing Duplicates:", df.shape)

# 3. Handle missing values (imputation)
# Numerical → replace with mean
num_cols = df.select_dtypes(include=['int64', 'float64']).columns
df[num_cols] = df[num_cols].fillna(df[num_cols].mean())

# Categorical → replace with mode
cat_cols = df.select_dtypes(include=['object']).columns
df[cat_cols] = df[cat_cols].fillna(df[cat_cols].mode().iloc[0])

# 4. Data transformation: create new feature
# Example: BMI = weight(kg) / height(m)^2
# (You can replace with a feature that exists in your dataset)
if 'weight' in df.columns and 'height' in df.columns:
    df['BMI'] = df['weight'] / (df['height'] ** 2)

# 5. Export cleaned dataset
df.to_csv("cleaned_dataset.csv", index=False)

print("Cleaned dataset saved as cleaned_dataset.csv")
