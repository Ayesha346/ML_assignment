import pandas as pd
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_curve, auc
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.multiclass import OneVsRestClassifier
import matplotlib.pyplot as plt
import seaborn as sns

# ------------------------------
# 1. LOAD DATASET (IRIS)
# ------------------------------
iris = load_iris()
X = pd.DataFrame(iris.data, columns=iris.feature_names)
y = pd.Series(iris.target)

print("\n=== Dataset Preview ===")
print(X.head())

# ------------------------------
# 2. PREPROCESSING
# ------------------------------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ------------------------------
# 3. TRAIN-TEST SPLIT
# ------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.3, random_state=42
)

# ------------------------------
# 4. MODELS TO TRAIN
# ------------------------------
models = {
    "Logistic Regression": LogisticRegression(max_iter=500),
    "Decision Tree": DecisionTreeClassifier(),
    "KNN": KNeighborsClassifier(n_neighbors=5),
    "SVM": SVC(probability=True),
    "ANN / MLP": MLPClassifier(hidden_layer_sizes=(10,10), max_iter=1500)
}

results = {}

# ------------------------------
# 5. TRAIN & EVALUATE MODELS
# ------------------------------
for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, average='macro')
    rec = recall_score(y_test, y_pred, average='macro')
    f1 = f1_score(y_test, y_pred, average='macro')

    results[name] = [acc, prec, rec, f1]

    print(f"\n==== {name} ====")
    print("Accuracy :", acc)
    print("Precision:", prec)
    print("Recall   :", rec)
    print("F1-score :", f1)

    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred)
    sns.heatmap(cm, annot=True, cmap="Blues", fmt="d")
    plt.title(f"Confusion Matrix - {name}")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()

# ------------------------------
# 6. ROC CURVES (One-vs-Rest)
# ------------------------------
plt.figure(figsize=(8,6))

for name, model in models.items():
    ovr = OneVsRestClassifier(model)
    ovr.fit(X_train, y_train)

    y_prob = ovr.predict_proba(X_test)

    for i in range(3):   # 3 classes in Iris
        fpr, tpr, _ = roc_curve(y_test == i, y_prob[:, i])
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, label=f"{name} - Class {i} (AUC={roc_auc:.2f})")

plt.plot([0,1], [0,1], 'k--')
plt.legend()
plt.title("ROC Curves for All Models (One-vs-Rest)")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.show()

# ------------------------------
# 7. FIND BEST MODEL
# ------------------------------
df_results = pd.DataFrame(results, index=["Accuracy", "Precision", "Recall", "F1-score"]).T

print("\n\n=== MODEL COMPARISON TABLE ===")
print(df_results)

best_model = df_results["Accuracy"].idxmax()
print(f"\n\n🏆 Best Performing Model: **{best_model}**")

