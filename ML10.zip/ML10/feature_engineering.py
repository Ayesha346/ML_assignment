import pandas as pd
import numpy as np
from sklearn.preprocessing import KBinsDiscretizer, MinMaxScaler, PowerTransformer
import matplotlib.pyplot as plt

# -----------------------------
# 1. Load Dataset
# -----------------------------
df = pd.read_csv("sales_data.csv")
print("\n=== Original Dataset ===")
print(df.head())

# -----------------------------
# 2. Feature Engineering
# -----------------------------

# Total Revenue = Quantity × Price
df["Total_Revenue"] = df["Quantity"] * df["Price"]

# Customer Purchase Frequency
customer_freq = df.groupby("Customer_ID")["Transaction_ID"].count().rename("Customer_Frequency")
df = df.merge(customer_freq, on="Customer_ID")

# Category-based Total Sales
category_sales = df.groupby("Category")["Total_Revenue"].sum()
print("\n=== Category-Based Sales ===")
print(category_sales)

print("\n=== Dataset with New Features ===")
print(df.head())

# -----------------------------
# 3. Discretization (binning)
# -----------------------------
binning_model = KBinsDiscretizer(n_bins=3, encode="ordinal", strategy="quantile")
df["Revenue_Bin"] = binning_model.fit_transform(df[["Total_Revenue"]])

print("\n=== Revenue Bins ===")
print(df[["Total_Revenue", "Revenue_Bin"]].head())

# -----------------------------
# 4. Transformation (log & power transform)
# -----------------------------
df["Log_Revenue"] = np.log1p(df["Total_Revenue"])  # log(1+x)
power = PowerTransformer()
df["Power_Revenue"] = power.fit_transform(df[["Total_Revenue"]])

print("\n=== Transformed Revenue Columns ===")
print(df[["Total_Revenue", "Log_Revenue", "Power_Revenue"]].head())

# -----------------------------
# 5. Outlier Detection using IQR
# -----------------------------
Q1 = df["Total_Revenue"].quantile(0.25)
Q3 = df["Total_Revenue"].quantile(0.75)
IQR = Q3 - Q1

lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR

outliers = df[(df["Total_Revenue"] < lower) | (df["Total_Revenue"] > upper)]

print("\n=== Outliers (by IQR) ===")
print(outliers)

# Plot Revenue Distribution
plt.figure(figsize=(6,4))
plt.boxplot(df["Total_Revenue"])
plt.title("Outlier Detection using Boxplot")
plt.ylabel("Revenue")
plt.grid()
plt.tight_layout()
plt.show()

# -----------------------------
# 6. Save Cleaned Dataset
# -----------------------------
df.to_csv("sales_cleaned.csv", index=False)
print("\n✔ cleaned dataset saved as sales_cleaned.csv")
