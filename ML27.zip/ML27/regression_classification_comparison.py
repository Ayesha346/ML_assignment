# Filename: regression_classification_comparison.py

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.preprocessing import StandardScaler

# ------------------- Regression Example ------------------- #
# Dataset: Housing Prices
df_reg = pd.DataFrame({
    'Area': [1200, 1500, 800, 950, 2000, 1700, 1300, 1600, 900, 1800],
    'Bedrooms': [3, 4, 2, 2, 4, 3, 3, 4, 2, 4],
    'Age': [10, 5, 20, 15, 7, 8, 12, 6, 18, 9],
    'Price': [200000, 260000, 120000, 150000, 310000, 280000, 210000, 290000, 140000, 320000]
})

X_reg = df_reg[['Area','Bedrooms','Age']]
y_reg = df_reg['Price']

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X_reg, y_reg, test_size=0.3, random_state=42)

# Linear Regression
lin_reg = LinearRegression()
lin_reg.fit(X_train, y_train)
y_pred_lin = lin_reg.predict(X_test)

# Random Forest Regression
rf_reg = RandomForestRegressor(n_estimators=100, random_state=42)
rf_reg.fit(X_train, y_train)
y_pred_rf = rf_reg.predict(X_test)

# Regression Metrics
print("=== Regression Comparison ===")
for model_name, y_pred in zip(["Linear Regression","Random Forest Regression"], [y_pred_lin, y_pred_rf]):
    print(f"{model_name}:")
    print(f"  R² Score : {r2_score(y_test, y_pred):.4f}")
    print(f"  RMSE     : {mean_squared_error(y_test, y_pred)**0.5:.4f}")
    print(f"  MAE      : {mean_absolute_error(y_test, y_pred):.4f}\n")

# ------------------- Classification Example ------------------- #
# Dataset: Customer Churn
df_clf = pd.DataFrame({
    'Age': [25,45,52,33,29,40,35,50,28,41],
    'MonthlyCharges':[300,600,550,400,700,500,450,650,350,480],
    'Tenure':[2,12,24,5,1,8,7,20,3,10],
    'Churn':[0,1,0,0,1,0,0,1,0,1]
})

X_clf = df_clf[['Age','MonthlyCharges','Tenure']]
y_clf = df_clf['Churn']

# Standardize Features
scaler = StandardScaler()
X_clf_scaled = scaler.fit_transform(X_clf)

# Train-Test Split
X_train_c, X_test_c, y_train_c, y_test_c = train_test_split(X_clf_scaled, y_clf, test_size=0.3, random_state=42)

# Logistic Regression
log_reg = LogisticRegression()
log_reg.fit(X_train_c, y_train_c)
y_pred_log = log_reg.predict(X_test_c)

# KNN Classifier
knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train_c, y_train_c)
y_pred_knn = knn.predict(X_test_c)

# Classification Metrics
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

print("=== Classification Comparison ===")
for model_name, y_pred in zip(["Logistic Regression","KNN"], [y_pred_log, y_pred_knn]):
    print(f"{model_name}:")
    print(f"  Accuracy  : {accuracy_score(y_test_c, y_pred):.4f}")
    print(f"  Precision : {precision_score(y_test_c, y_pred):.4f}")
    print(f"  Recall    : {recall_score(y_test_c, y_pred):.4f}")
    print(f"  F1-score  : {f1_score(y_test_c, y_pred):.4f}\n")
