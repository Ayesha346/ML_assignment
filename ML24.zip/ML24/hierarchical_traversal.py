# Sample hierarchical data: Organization chart
org_chart = {
    'CEO': {
        'VP_Sales': {
            'Manager1': None,
            'Manager2': None
        },
        'VP_Tech': {
            'Dev_Manager': {
                'Developer1': None,
                'Developer2': None
            },
            'QA_Manager': None
        },
        'CFO': None
    }
}

# Recursive function to get all leaf nodes
def get_leaves(tree, path=[]):
    leaves = []
    for key, value in tree.items():
        current_path = path + [key]
        if value is None or len(value) == 0:  # leaf node
            leaves.append(current_path)
        else:
            leaves.extend(get_leaves(value, current_path))
    return leaves

# Recursive function to get nodes at a specific depth
def get_nodes_at_depth(tree, depth, path=[]):
    nodes = []
    for key, value in tree.items():
        current_path = path + [key]
        if len(current_path) == depth:
            nodes.append(current_path)
        if value:
            nodes.extend(get_nodes_at_depth(value, depth, current_path))
    return nodes

# Usage
all_leaves = get_leaves(org_chart)
nodes_depth_2 = get_nodes_at_depth(org_chart, 2)

# Display results
print("=== All Leaves ===")
for leaf in all_leaves:
    print(" -> ".join(leaf))

print("\n=== Nodes at Depth 2 ===")
for node in nodes_depth_2:
    print(" -> ".join(node))
