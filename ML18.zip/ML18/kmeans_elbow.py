import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

# -----------------------------
# 1. Generate Unlabeled Dataset (Customer-like data)
# -----------------------------
X, _ = make_blobs(n_samples=300, centers=5, cluster_std=1.5, random_state=42)
df = pd.DataFrame(X, columns=['AnnualIncome', 'SpendingScore'])

print("\n=== Dataset Preview ===")
print(df.head())

# -----------------------------
# 2. Standardization
# -----------------------------
scaler = StandardScaler()
scaled_data = scaler.fit_transform(df)

# -----------------------------
# 3. Elbow Method to find optimal K
# -----------------------------
inertia = []
K_range = range(1, 11)

for k in K_range:
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(scaled_data)
    inertia.append(kmeans.inertia_)

# Plot Elbow Curve
plt.figure(figsize=(6,4))
plt.plot(K_range, inertia, 'bo-')
plt.xlabel("Number of Clusters (K)")
plt.ylabel("Inertia / Sum of Squared Distances")
plt.title("Elbow Method for Optimal K")
plt.grid()
plt.show()

# -----------------------------
# 4. Apply K-Means with chosen K
# -----------------------------
optimal_k = 5  # Chosen based on elbow plot
kmeans_final = KMeans(n_clusters=optimal_k, random_state=42)
df['Cluster'] = kmeans_final.fit_predict(scaled_data)

# -----------------------------
# 5. Visualize Final Clusters
# -----------------------------
plt.figure(figsize=(6,4))
plt.scatter(df['AnnualIncome'], df['SpendingScore'], c=df['Cluster'], cmap='Set1')
plt.xlabel("Annual Income")
plt.ylabel("Spending Score")
plt.title(f"K-Means Clusters (K={optimal_k})")
plt.show()

# -----------------------------
# 6. Cluster Summary
# -----------------------------
cluster_summary = df.groupby('Cluster').mean()
print("\n=== Cluster Summary ===")
print(cluster_summary)
