import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import zscore
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# ----------------------------------------------------
# 1. LOAD DATASET
# ----------------------------------------------------
data = pd.read_csv("salary_data.csv")
print("\nFirst 5 Rows:\n", data.head())

# ----------------------------------------------------
# 2. Z-SCORE OUTLIER DETECTION
# ----------------------------------------------------
data["Z_Score"] = zscore(data["Salary"])

z_outliers = data[data["Z_Score"].abs() > 3]
print("\nZ-Score Outliers:\n", z_outliers)

# ----------------------------------------------------
# 3. IQR OUTLIER DETECTION
# ----------------------------------------------------
Q1 = data["Salary"].quantile(0.25)
Q3 = data["Salary"].quantile(0.75)
IQR = Q3 - Q1

lower_limit = Q1 - 1.5 * IQR
upper_limit = Q3 + 1.5 * IQR

iqr_outliers = data[(data["Salary"] < lower_limit) | (data["Salary"] > upper_limit)]
print("\nIQR Outliers:\n", iqr_outliers)

# ----------------------------------------------------
# 4. VISUALIZATION
# ----------------------------------------------------

plt.figure(figsize=(10,5))

# Boxplot
plt.subplot(1,2,1)
plt.boxplot(data["Salary"])
plt.title("Salary Boxplot (With Outliers)")

# Histogram
plt.subplot(1,2,2)
plt.hist(data["Salary"], bins=25)
plt.title("Salary Distribution")

plt.tight_layout()
plt.show()

# ----------------------------------------------------
# 5. MODEL PERFORMANCE BEFORE HANDLING OUTLIERS
# ----------------------------------------------------
X = data[["Experience"]]
y = data["Salary"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model_before = LinearRegression()
model_before.fit(X_train, y_train)

pred_before = model_before.predict(X_test)
mse_before = mean_squared_error(y_test, pred_before)

print("\nMSE BEFORE Removing Outliers:", mse_before)

# ----------------------------------------------------
# 6. REMOVE OUTLIERS USING IQR (Better Method)
# ----------------------------------------------------
cleaned_data = data[(data["Salary"] >= lower_limit) & (data["Salary"] <= upper_limit)]

X_clean = cleaned_data[["Experience"]]
y_clean = cleaned_data["Salary"]

X_train2, X_test2, y_train2, y_test2 = train_test_split(
    X_clean, y_clean, test_size=0.2, random_state=42
)

model_after = LinearRegression()
model_after.fit(X_train2, y_train2)

pred_after = model_after.predict(X_test2)
mse_after = mean_squared_error(y_test2, pred_after)

print("\nMSE AFTER Removing Outliers:", mse_after)

# ----------------------------------------------------
# 7. RESULT SUMMARY
# ----------------------------------------------------
print("\n--------------------- SUMMARY ---------------------")
print("Before Removing Outliers MSE :", mse_before)
print("After Removing Outliers MSE  :", mse_after)
print("----------------------------------------------------")
