import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import math

# -----------------------------
# 1. Load dataset
# -----------------------------
df = pd.read_csv("house_prices.csv")
print("=== Dataset ===")
print(df.head(), "\n")

# Features & target
X = df[['Area', 'Bedrooms', 'Age']]
y = df['Price']

# -----------------------------
# 2. Feature Scaling
# -----------------------------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

print("=== Scaled Features ===")
print(X_scaled[:5], "\n")

# -----------------------------
# 3. Train-test split
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

# -----------------------------
# 4. Train Linear Regression
# -----------------------------
model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

# -----------------------------
# 5. Evaluation Metrics
# -----------------------------
r2 = r2_score(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
rmse = math.sqrt(mean_squared_error(y_test, y_pred))

print("=== Linear Regression Results ===")
print("R² Score :", r2)
print("MAE      :", mae)
print("RMSE     :", rmse, "\n")

# -----------------------------
# 6. Regularization: Ridge & Lasso
# -----------------------------
ridge = Ridge(alpha=1.0)
ridge.fit(X_train, y_train)
ridge_pred = ridge.predict(X_test)

lasso = Lasso(alpha=0.1)
lasso.fit(X_train, y_train)
lasso_pred = lasso.predict(X_test)

# Ridge Evaluation
print("=== Ridge Regression ===")
print("R²:", r2_score(y_test, ridge_pred))
print("RMSE:", math.sqrt(mean_squared_error(y_test, ridge_pred)), "\n")

# Lasso Evaluation
print("=== Lasso Regression ===")
print("R²:", r2_score(y_test, lasso_pred))
print("RMSE:", math.sqrt(mean_squared_error(y_test, lasso_pred)), "\n")

