import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.datasets import make_blobs

# -----------------------------
# Generate Synthetic Customer Dataset
# -----------------------------
X, _ = make_blobs(n_samples=200, centers=4, cluster_std=1.2, random_state=42)
df = pd.DataFrame(X, columns=['AnnualIncome', 'SpendingScore'])

print("\n=== Dataset Preview ===")
print(df.head())

# -----------------------------
# Standardization
# -----------------------------
scaler = StandardScaler()
scaled_data = scaler.fit_transform(df)

# -----------------------------
# K-Means Clustering
# -----------------------------
kmeans = KMeans(n_clusters=4, random_state=42)
df['KMeans_Cluster'] = kmeans.fit_predict(scaled_data)

# -----------------------------
# Hierarchical Clustering
# -----------------------------
hier = AgglomerativeClustering(n_clusters=4, linkage='ward')
df['Hier_Cluster'] = hier.fit_predict(scaled_data)

# -----------------------------
# Visualization: K-Means
# -----------------------------
plt.figure(figsize=(6,4))
plt.scatter(df['AnnualIncome'], df['SpendingScore'], c=df['KMeans_Cluster'])
plt.title("K-Means Clustering")
plt.xlabel("Annual Income")
plt.ylabel("Spending Score")
plt.show()

# -----------------------------
# Visualization: Hierarchical
# -----------------------------
plt.figure(figsize=(6,4))
plt.scatter(df['AnnualIncome'], df['SpendingScore'], c=df['Hier_Cluster'])
plt.title("Hierarchical Clustering")
plt.xlabel("Annual Income")
plt.ylabel("Spending Score")
plt.show()

# -----------------------------
# Dendrogram
# -----------------------------
plt.figure(figsize=(8,5))
linkage_matrix = linkage(scaled_data, method='ward')
dendrogram(linkage_matrix)
plt.title("Hierarchical Clustering Dendrogram")
plt.xlabel("Customers")
plt.ylabel("Distance")
plt.show()

# -----------------------------
# Final Cluster Comparison
# -----------------------------
print("\n=== Cluster Comparison ===")
print(df.groupby('KMeans_Cluster').mean())
print("\n")
print(df.groupby('Hier_Cluster').mean())
