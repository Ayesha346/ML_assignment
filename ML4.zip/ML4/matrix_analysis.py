import numpy as np

# --------------------------------------------------------------
# FUNCTION DEFINITIONS
# --------------------------------------------------------------

def element_wise_operations(A, B):
    """Perform element-wise addition, subtraction, multiplication, and division."""
    add = A + B
    subtract = A - B
    multiply = A * B
    divide = A / (B + 1e-8)  # prevent divide-by-zero error
    return add, subtract, multiply, divide


def compute_statistics(matrix):
    """Return mean, median, variance, and standard deviation of a matrix."""
    mean_val = np.mean(matrix)
    median_val = np.median(matrix)
    variance_val = np.var(matrix)
    std_val = np.std(matrix)
    return mean_val, median_val, variance_val, std_val


def matrix_multiplication(A, B):
    """Perform matrix multiplication if dimensions allow, otherwise return None."""
    if A.shape[1] == B.shape[0]:
        return A @ B       # matrix multiplication using @ operator
    else:
        return None        # incompatible shapes


# --------------------------------------------------------------
# 1. MATRIX CREATION (100x100)
# --------------------------------------------------------------

# Creating large random matrices representing different measurements
# Documented: Using np.random.rand() to generate values between 0 and 1

A = np.random.rand(100, 100)   # Matrix A (100x100)
B = np.random.rand(100, 100)   # Matrix B (100x100)

print("Matrix A shape:", A.shape)
print("Matrix B shape:", B.shape)


# --------------------------------------------------------------
# 2. ELEMENT-WISE OPERATIONS
# --------------------------------------------------------------

add, subtract, multiply, divide = element_wise_operations(A, B)

print("\nElement-wise addition completed.")
print("Element-wise subtraction completed.")
print("Element-wise multiplication completed.")
print("Element-wise division completed.")


# --------------------------------------------------------------
# 3. STATISTICAL FUNCTIONS FOR EACH MATRIX
# --------------------------------------------------------------

A_stats = compute_statistics(A)
B_stats = compute_statistics(B)

print("\n--- Statistics for Matrix A ---")
print("Mean:", A_stats[0])
print("Median:", A_stats[1])
print("Variance:", A_stats[2])
print("Standard Deviation:", A_stats[3])

print("\n--- Statistics for Matrix B ---")
print("Mean:", B_stats[0])
print("Median:", B_stats[1])
print("Variance:", B_stats[2])
print("Standard Deviation:", B_stats[3])


# --------------------------------------------------------------
# 4. MATRIX MULTIPLICATION OR BROADCASTING
# --------------------------------------------------------------

# Since both are 100x100, multiplication is possible
matmul_result = matrix_multiplication(A, B)

if matmul_result is not None:
    print("\nMatrix multiplication successful! Result shape:", matmul_result.shape)
else:
    # Broadcasting example: adding a 1D array of length 100 to each row
    broadcast_vector = np.random.rand(100)
    broadcast_result = A + broadcast_vector
    print("\nMatrix multiplication not possible, broadcasting done instead.")
    print("Broadcast result shape:", broadcast_result.shape)


# --------------------------------------------------------------
# DOCUMENTATION OF RESHAPING (EXAMPLE)
# --------------------------------------------------------------

# Example: Reshape A to (50x200) just to demonstrate reshaping
A_reshaped = A.reshape(50, 200)
print("\nReshaped Matrix A shape (50 x 200):", A_reshaped.shape)

