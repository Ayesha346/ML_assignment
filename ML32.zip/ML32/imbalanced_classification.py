# imbalanced_classification.py

import pandas as pd
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from imblearn.over_sampling import SMOTE

# --------------------------
# 1. Create synthetic imbalanced dataset
# --------------------------
X, y = make_classification(n_samples=2000, n_features=10, n_informative=5, n_redundant=2,
                           n_clusters_per_class=1, weights=[0.9, 0.1], flip_y=0, random_state=42)

print(f"Original class distribution: {np.bincount(y)}")

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

# --------------------------
# 2. Train classifier on original imbalanced data
# --------------------------
clf = RandomForestClassifier(random_state=42)
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)

print("\n=== Classification Report (Original Data) ===")
print(classification_report(y_test, y_pred))
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# --------------------------
# 3. Apply SMOTE for oversampling minority class
# --------------------------
smote = SMOTE(random_state=42)
X_train_res, y_train_res = smote.fit_resample(X_train, y_train)
print(f"\nResampled class distribution: {np.bincount(y_train_res)}")

# Train classifier on balanced data
clf_res = RandomForestClassifier(random_state=42)
clf_res.fit(X_train_res, y_train_res)
y_pred_res = clf_res.predict(X_test)

print("\n=== Classification Report (After SMOTE) ===")
print(classification_report(y_test, y_pred_res))
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred_res))

