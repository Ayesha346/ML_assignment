import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# ----------------------------
#  1. LOAD DATA
# ----------------------------
df = pd.read_csv("stock_data.csv", parse_dates=["Date"])
df.set_index("Date", inplace=True)

print("\n=== Original Data ===")
print(df.head())

# ----------------------------
#  2. RESAMPLING (Weekly Mean)
# ----------------------------
df_resampled = df.resample("W").mean()
print("\n=== Weekly Resampled Data ===")
print(df_resampled)

# ----------------------------
#  3. ROLLING MEAN (3-day)
# ----------------------------
df["Rolling_Close"] = df["Close"].rolling(window=3).mean()
print("\n=== Rolling 3-Day Mean ===")
print(df[["Close", "Rolling_Close"]])

# ----------------------------
#  4. DIFFERENCING
# ----------------------------
df["Close_Diff"] = df["Close"].diff()
print("\n=== Close Price Differencing ===")
print(df[["Close", "Close_Diff"]])

# ----------------------------
#  5. TIME-BASED FEATURES
# ----------------------------
df["Year"] = df.index.year
df["Month"] = df.index.month
df["Day"] = df.index.day
df["DayOfWeek"] = df.index.dayofweek

# Remove NaN (due to differencing & rolling)
df = df.dropna()

# ----------------------------
#  6. BUILD REGRESSION MODEL
# ----------------------------
X = df[["Open", "High", "Low", "Volume", "Rolling_Close", "Close_Diff", 
        "Year", "Month", "Day", "DayOfWeek"]]
y = df["Close"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("\n=== Regression Model Performance ===")
print("MSE:", mean_squared_error(y_test, y_pred))
print("R² Score:", r2_score(y_test, y_pred))

# ----------------------------
#  7. OPTIONAL: K-MEANS CLUSTERING
# ----------------------------
from sklearn.cluster import KMeans

kmeans = KMeans(n_clusters=2, random_state=42)
df["Cluster"] = kmeans.fit_predict(df[["Close_Diff", "Rolling_Close"]])

print("\n=== Cluster Labels Added ===")
print(df[["Close", "Close_Diff", "Rolling_Close", "Cluster"]])
