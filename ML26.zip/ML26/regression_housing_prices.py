# regression_housing_prices.py
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

# ===== Dataset =====
data = {
    "Area": [1200, 1500, 800, 950, 2000, 1700, 1300, 1600, 900, 1800],
    "Bedrooms": [3, 4, 2, 2, 4, 3, 3, 4, 2, 4],
    "Age": [10, 5, 20, 15, 7, 8, 12, 6, 18, 9],
    "Price": [200000, 260000, 120000, 150000, 310000, 280000, 210000, 290000, 140000, 320000]
}

df = pd.DataFrame(data)
print("=== Dataset ===")
print(df)

# Features and target
X = df[["Area", "Bedrooms", "Age"]]
y = df["Price"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ===== Linear Regression =====
lin_reg = LinearRegression()
lin_reg.fit(X_train, y_train)
y_pred_lin = lin_reg.predict(X_test)

print("\n=== Linear Regression ===")
print(f"R² Score : {r2_score(y_test, y_pred_lin):.4f}")
rmse_lin = np.sqrt(mean_squared_error(y_test, y_pred_lin))
print(f"RMSE     : {rmse_lin:.4f}")
print(f"MAE      : {mean_absolute_error(y_test, y_pred_lin):.4f}")

# ===== Polynomial Regression =====
poly = PolynomialFeatures(degree=2, include_bias=False)
X_train_poly = poly.fit_transform(X_train)
X_test_poly = poly.transform(X_test)

poly_reg = LinearRegression()
poly_reg.fit(X_train_poly, y_train)
y_pred_poly = poly_reg.predict(X_test_poly)

print("\n=== Polynomial Regression ===")
print(f"R² Score : {r2_score(y_test, y_pred_poly):.4f}")
rmse_poly = np.sqrt(mean_squared_error(y_test, y_pred_poly))
print(f"RMSE     : {rmse_poly:.4f}")
print(f"MAE      : {mean_absolute_error(y_test, y_pred_poly):.4f}")

# ===== Ridge Regression (Polynomial Features) =====
scaler = StandardScaler()
X_train_poly_scaled = scaler.fit_transform(X_train_poly)
X_test_poly_scaled = scaler.transform(X_test_poly)

ridge = Ridge(alpha=1.0)
ridge.fit(X_train_poly_scaled, y_train)
y_pred_ridge = ridge.predict(X_test_poly_scaled)

print("\n=== Ridge Regression (Poly Features) ===")
print(f"R² Score : {r2_score(y_test, y_pred_ridge):.4f}")
rmse_ridge = np.sqrt(mean_squared_error(y_test, y_pred_ridge))
print(f"RMSE     : {rmse_ridge:.4f}")
print(f"MAE      : {mean_absolute_error(y_test, y_pred_ridge):.4f}")

